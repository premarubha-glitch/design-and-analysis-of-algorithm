
def interpolation_search(records, key):
    low = 0
    high = len(records) - 1
    comparisons = 0

    while low <= high and records[low] <= key <= records[high]:
        if records[low] == records[high]:
            comparisons += 1
            if records[low] == key:
                return low, comparisons
            return -1, comparisons

        pos = low + int(
            (key - records[low]) * (high - low)
            / (records[high] - records[low])
        )

        comparisons += 1

        if records[pos] == key:
            return pos, comparisons

        if records[pos] < key:
            low = pos + 1
        else:
            high = pos - 1

    return -1, comparisons


if __name__ == "__main__":
    records = [
        192525010,
        192525015,
        192525020,
        192525025,
        192525030
    ]

    print("Reg No: 192525020")
    print("Algorithm: Interpolation Search")

    for key in [192525020, 192525021]:
        index, comparisons = interpolation_search(records, key)

        print("\nSearch Key:", key)
        print("Index:", index)
        print("Comparisons:", comparisons)

        if index != -1:
            print("Status: Found")
        else:
            print("Status: Not Found")