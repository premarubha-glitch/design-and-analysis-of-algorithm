
import os
import pandas as pd
import matplotlib.pyplot as plt

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
RESULTS_DIR = os.path.join(BASE_DIR, "results")
GRAPH_DIR = os.path.join(RESULTS_DIR, "graphs")

CSV_FILE = os.path.join(RESULTS_DIR, "results.csv")

os.makedirs(GRAPH_DIR, exist_ok=True)

df = pd.read_csv(CSV_FILE)

sizes = [1000, 10000, 100000, 1000000]
algorithms = [
    "Linear Search",
    "Binary Search",
    "Interpolation Search"
]

summary = df.groupby(
    ["Dataset_Size", "Algorithm"], as_index=False
).agg(
    Average_Comparisons=("Comparisons", "mean"),
    Average_Search_Time_ms=("Search_Time_ms", "mean"),
    Average_Preprocessing_Time_ms=("Preprocessing_Time_ms", "mean"),
    Average_Total_Time_ms=("Total_Time_ms", "mean")
)

summary.to_csv(
    os.path.join(RESULTS_DIR, "summary_results.csv"),
    index=False
)

for column, ylabel, filename, title in [
    (
        "Average_Comparisons",
        "Average Number of Comparisons",
        "comparisons.png",
        "Average Comparisons by Dataset Size"
    ),
    (
        "Average_Search_Time_ms",
        "Average Search Time (ms)",
        "search_time.png",
        "Average Search Time by Dataset Size"
    ),
    (
        "Average_Total_Time_ms",
        "Average Total Time (ms)",
        "total_time.png",
        "Average Total Time Including Preprocessing"
    )
]:
    plt.figure(figsize=(9, 6))

    for algorithm in algorithms:
        data = summary[summary["Algorithm"] == algorithm]

        plt.plot(
            data["Dataset_Size"],
            data[column],
            marker="o",
            label=algorithm
        )

    plt.xscale("log")
    plt.yscale("log")
    plt.xlabel("Dataset Size (number of records)")
    plt.ylabel(ylabel)
    plt.title(title)
    plt.legend()
    plt.grid(True, which="both", linestyle="--", alpha=0.5)
    plt.tight_layout()
    plt.savefig(os.path.join(GRAPH_DIR, filename), dpi=300)
    plt.close()

print("Reg No: 192525020")
print("Graphs generated from results.csv")
print("Summary saved to:", os.path.join(RESULTS_DIR, "summary_results.csv"))
print("Graph folder:", GRAPH_DIR)
print("Files created:")
print("1. comparisons.png")
print("2. search_time.png")
print("3. total_time.png")