
import csv
import random
import time
import os
from datetime import datetime

from binary_search import binary_search
from interpolation_search import interpolation_search

REG_NO = 192525020
SEED = 5020
SEARCH_COUNT = 50000

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DATA_FILE = os.path.join(BASE_DIR, "data", "students_1000000.csv")
OUTPUT_FILE = os.path.join(BASE_DIR, "results", "task12_results.csv")


def load_registration_numbers():
    numbers = []

    with open(DATA_FILE, "r", newline="", encoding="utf-8") as file:
        reader = csv.DictReader(file)

        for row in reader:
            numbers.append(int(row["Registration_Number"]))

    return numbers


def main():
    print("DAA Task 12: Large-Scale Search Benchmark")
    print("Registration Number:", REG_NO)
    print("System Date and Time:", datetime.now().strftime("%Y-%m-%d %H:%M:%S"))

    numbers = load_registration_numbers()
    sort_start = time.perf_counter()
    sorted_numbers = sorted(numbers)
    sorting_time_ms = (time.perf_counter() - sort_start) * 1000
    print("Sorting Time (ms):", round(sorting_time_ms, 3))

    random_generator = random.Random(SEED)
    queries = []

    for i in range(SEARCH_COUNT // 2):
        queries.append(random_generator.choice(numbers))

    queries.append(REG_NO)

    while len(queries) < SEARCH_COUNT:
        queries.append(REG_NO + 1)

    random_generator.shuffle(queries)

    algorithms = [
        ("Binary Search", binary_search),
        ("Interpolation Search", interpolation_search)
    ]

    results = []

    for name, search_function in algorithms:
        total_comparisons = 0

        start = time.perf_counter()

        for key in queries:
            found, comparisons = search_function(sorted_numbers, key, 0, len(sorted_numbers) - 1) if name == "Binary Search" else search_function(sorted_numbers, key)
            total_comparisons += comparisons

        search_time_ms = (time.perf_counter() - start) * 1000

        results.append({
            "Algorithm": name,
            "Dataset_Size": len(sorted_numbers),
            "Search_Count": SEARCH_COUNT,
            "Total_Comparisons": total_comparisons,
            "Average_Comparisons": total_comparisons / SEARCH_COUNT,
            "Sorting_Time_ms": sorting_time_ms,
            "Search_Time_ms": search_time_ms,
            "Total_Time_ms": sorting_time_ms + search_time_ms
        })

        print("\nAlgorithm:", name)
        print("Dataset Size:", len(sorted_numbers))
        print("Searches:", SEARCH_COUNT)
        print("Total Comparisons:", total_comparisons)
        print("Average Comparisons:", round(total_comparisons / SEARCH_COUNT, 2))
        print("Total Search Time (ms):", round(search_time_ms, 3))

    os.makedirs(os.path.dirname(OUTPUT_FILE), exist_ok=True)

    with open(OUTPUT_FILE, "w", newline="", encoding="utf-8") as file:
        writer = csv.DictWriter(file, fieldnames=results[0].keys())
        writer.writeheader()
        writer.writerows(results)

    print("\nResults saved to:", OUTPUT_FILE)


if __name__ == "__main__":
    main()