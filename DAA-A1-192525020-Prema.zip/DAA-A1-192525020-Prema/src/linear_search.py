def linear_search(records, key):
    comparisons = 0

    for i in range(len(records)):
        comparisons += 1

        if records[i] == key:
            return i, comparisons

    return -1, comparisons


if __name__ == "__main__":
    records = [192525010, 192525015, 192525020, 192525025, 192525030]

    key = 192525020

    index, comparisons = linear_search(records, key)

    print("Registration Number: 192525020")
    print("Search Key:", key)
    print("Index:", index)
    print("Comparisons:", comparisons)

    key = 192525021

    index, comparisons = linear_search(records, key)

    print()
    print("Search Key:", key)
    print("Index:", index)
    print("Comparisons:", comparisons)