
def binary_search(records, key, low, high, comparisons=0):
    if low > high:
        return -1, comparisons

    mid = (low + high) // 2
    comparisons += 1

    if records[mid] == key:
        return mid, comparisons

    if key < records[mid]:
        return binary_search(records, key, low, mid - 1, comparisons)

    return binary_search(records, key, mid + 1, high, comparisons)


if __name__ == "__main__":
    records = [
        192525010,
        192525015,
        192525020,
        192525025,
        192525030
    ]

    print("Reg No: 192525020")
    print("Algorithm: Recursive Binary Search")

    for key in [192525020, 192525021]:
        index, comparisons = binary_search(
            records, key, 0, len(records) - 1
        )

        print("\nSearch Key:", key)
        print("Index:", index)
        print("Comparisons:", comparisons)

        if index != -1:
            print("Status: Found")
        else:
            print("Status: Not Found")