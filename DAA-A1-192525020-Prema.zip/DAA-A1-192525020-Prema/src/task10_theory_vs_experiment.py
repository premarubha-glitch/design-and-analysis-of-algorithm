
import os
import math
import pandas as pd
import matplotlib.pyplot as plt

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
RESULTS_FILE = os.path.join(BASE_DIR, "results", "results.csv")
GRAPH_DIR = os.path.join(BASE_DIR, "results", "graphs")

os.makedirs(GRAPH_DIR, exist_ok=True)

df = pd.read_csv(RESULTS_FILE)

summary = df.groupby(["Dataset_Size", "Algorithm"])["Comparisons"].mean().reset_index()

sizes = sorted(summary["Dataset_Size"].unique())

plt.figure(figsize=(12, 7))

theory = {
    "Linear Search": [n for n in sizes],
    "Binary Search": [math.log2(n) for n in sizes],
    "Interpolation Search": [math.log2(math.log2(n)) for n in sizes]
}

for algorithm, values in theory.items():
    plt.plot(sizes, values, marker="o", linestyle="--",
             label=f"{algorithm} - Theoretical Growth")

for algorithm in summary["Algorithm"].unique():
    data = summary[summary["Algorithm"] == algorithm]
    plt.plot(data["Dataset_Size"], data["Comparisons"],
             marker="s", label=f"{algorithm} - Experimental")

plt.xscale("log")
plt.yscale("log")
plt.xlabel("Dataset Size (n)")
plt.ylabel("Number of Comparisons (log scale)")
plt.title("Task 10: Theoretical vs Experimental Search Performance")
plt.grid(True, which="both", linestyle=":")
plt.legend()
plt.tight_layout()

output_path = os.path.join(GRAPH_DIR, "task10_theory_vs_experiment.png")
plt.savefig(output_path, dpi=300)
plt.show()

print("Task 10 graph saved to:", output_path)