
import csv
import os
import time
import platform
from datetime import datetime

from linear_search import linear_search
from binary_search import binary_search
from interpolation_search import interpolation_search

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DATA_DIR = os.path.join(BASE_DIR, "data")
RESULTS_DIR = os.path.join(BASE_DIR, "results")

REG_NO = 192525020
SIZES = [1000, 10000, 100000, 1000000]


def load_records(filename):
    with open(filename, "r", newline="") as file:
        reader = csv.DictReader(file)
        return [
            int(row["Registration_Number"])
            for row in reader
        ]


def main():
    os.makedirs(RESULTS_DIR, exist_ok=True)
    output_file = os.path.join(RESULTS_DIR, "results.csv")
    all_results = []

    print("DAA Assignment 1 - Benchmark Results")
    print("Reg No:", REG_NO)
    print("Date and Time:", datetime.now().strftime("%Y-%m-%d %H:%M:%S"))
    print("System:", platform.platform())
    print("=" * 105)

    for size in SIZES:
        filename = os.path.join(DATA_DIR, f"students_{size}.csv")
        records = load_records(filename)

        start = time.perf_counter()
        sorted_records = sorted(records)
        preprocessing_ms = (time.perf_counter() - start) * 1000

        tests = [
            (REG_NO, "Found"),
            (REG_NO + 1, "Not Found")
        ]

        for algorithm in [
            "Linear Search",
            "Binary Search",
            "Interpolation Search"
        ]:
            for key, case_name in tests:
                search_records = (
                    records if algorithm == "Linear Search"
                    else sorted_records
                )

                start = time.perf_counter()

                if algorithm == "Linear Search":
                    index, comparisons = linear_search(
                        search_records, key
                    )
                    prep_ms = 0.0

                elif algorithm == "Binary Search":
                    index, comparisons = binary_search(
                        search_records, key, 0,
                        len(search_records) - 1
                    )
                    prep_ms = preprocessing_ms

                else:
                    index, comparisons = interpolation_search(
                        search_records, key
                    )
                    prep_ms = preprocessing_ms

                search_ms = (time.perf_counter() - start) * 1000
                status = "Found" if index != -1 else "Not Found"

                result = {
                    "Registration_Number": REG_NO,
                    "Dataset_Size": size,
                    "Algorithm": algorithm,
                    "Test_Case": case_name,
                    "Search_Key": key,
                    "Status": status,
                    "Index": index,
                    "Comparisons": comparisons,
                    "Search_Time_ms": round(search_ms, 6),
                    "Preprocessing_Time_ms": round(prep_ms, 6),
                    "Total_Time_ms": round(search_ms + prep_ms, 6)
                }

                all_results.append(result)

                print(
                    f"n={size:>7} | {algorithm:<22} | "
                    f"{case_name:<9} | {status:<9} | "
                    f"Comparisons={comparisons:<8} | "
                    f"Search={search_ms:.6f} ms | "
                    f"Preprocessing={prep_ms:.6f} ms"
                )

    with open(output_file, "w", newline="") as file:
        writer = csv.DictWriter(
            file, fieldnames=all_results[0].keys()
        )
        writer.writeheader()
        writer.writerows(all_results)

    print("=" * 105)
    print("Results saved to:", output_file)
    print("Total test runs:", len(all_results))
    print("Benchmark completed.")


if __name__ == "__main__":
    main()