import csv
import random
import os

SEED = 5020

SIZES = [1000, 10000, 100000, 1000000]

OUTPUT_DIR = os.path.join(
    os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
    "data"
)

random.seed(SEED)


def generate_student(reg_no):
    names = [
        "Arun", "Bala", "Charan", "Deepak", "Divya",
        "Harish", "Karthik", "Meena", "Naveen", "Priya",
        "Rahul", "Ravi", "Sneha", "Surya", "Vijay"
    ]

    departments = [
        "CSE", "ECE", "EEE", "MECH", "CIVIL"
    ]

    return [
        reg_no,
        random.choice(names),
        random.choice(departments),
        random.randint(18, 24)
    ]


def generate_dataset(size):
    random.seed(SEED + size)

    records = []
    used_reg_numbers = set()

    personal_reg_no = 192525020

    records.append(generate_student(personal_reg_no))
    used_reg_numbers.add(personal_reg_no)

    while len(records) < size:
        reg_no = random.randint(100000000, 999999999)

        if reg_no == 192525021:
            continue

        if reg_no not in used_reg_numbers:
            records.append(generate_student(reg_no))
            used_reg_numbers.add(reg_no)

    random.shuffle(records)

    filename = os.path.join(
        OUTPUT_DIR,
        f"students_{size}.csv"
    )

    with open(filename, "w", newline="") as file:
        writer = csv.writer(file)

        writer.writerow([
            "Registration_Number",
            "Name",
            "Department",
            "Age"
        ])

        writer.writerows(records)

    print(f"Created: students_{size}.csv")
    print(f"Records: {size}")


def main():
    os.makedirs(OUTPUT_DIR, exist_ok=True)

    print("DAA Assignment 1 - Dataset Generator")
    print("Registration Number: 192525020")
    print("Random Seed: 5020")
    print()

    for size in SIZES:
        generate_dataset(size)

    print()
    print("All datasets generated successfully.")


if __name__ == "__main__":
    main()